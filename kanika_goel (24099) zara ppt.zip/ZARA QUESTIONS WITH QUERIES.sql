Create database ClothingBrand;
Use ClothingBrand;
create table zara;
select * from zara;
desc zara;
Alter table zara
Add primary key (Product_ID);
Alter table zara DROP column url;
select count(*) from zara;

/* what are the minimum, maximum, average shopping of the store.*/
select
round(min(price), 2) as Min_price,
round(max(price), 2) as Max_price,
round(avg(price), 2) as Avg_price 
from zara;

/* What is the distribution of price for the store? desc-descending.*/
select price, count(*) as frequency
from zara
group by price
order by price desc;

/*Find the top 5 most sold products based on sales volume.*/
SELECT name, SUM(Sales_Volume) 
FROM zara 
GROUP BY name ORDER BY SUM(Sales_Volume) DESC LIMIT 5;


/*List the total sales volume for each product category.*/
SELECT Product_Category, SUM(Sales_Volume) 
FROM zara 
GROUP BY Product_Category;


/*Calculate the total revenue generated per section (MAN, WOMAN, etc.).*/
SELECT section, SUM(price * Sales_Volume) 
AS revenue 
FROM zara 
GROUP BY section;


/*List all the products that have never been promoted.*/
SELECT name FROM zara WHERE Promotion = 'No';


/*Get the average price of all products in each product category.*/
SELECT Product_Category, AVG(price) 
FROM zara 
GROUP BY Product_Category;




/*Identify products that were promoted and had sales volume above a certain threshold.*/
SELECT name, Sales_Volume
 FROM zara WHERE Promotion = 'Yes' AND 
 Sales_Volume > 1000;



/*Calculate the difference in total sales volume between products that are seasonal vs. non-seasonal.*/
SELECT Seasonal, SUM(Sales_Volume) 
FROM zara 
GROUP BY Seasonal;


/*Determine how many products are placed in aisles vs. end-caps and compare their total sales volume.*/
SELECT Product_Position, SUM(Sales_Volume) 
FROM zara 
GROUP BY Product_Position;




/* Rank():*/
SELECT sales_volume,name,
Rank()
OVER (ORDER BY sales_volume Desc) AS unique_rank FROM zara Limit 10;